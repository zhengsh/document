#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * ClassName: ${NAME}. <br/>
 * Description: 商业云平台服务-. <br/>
 * Date: ${DATE}. <br/>
 * 
 * @author YCKJ1569
 * @version 1.0.0
 * @since 1.7
 */
public class ${NAME} {
}
