change master to master_host='master', master_user='root', master_password='123456';
reset slave;
start slave;
